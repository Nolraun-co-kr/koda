<footer class="footer">
        <div class="footer__partners">
          <div class="wrap">
            <div class="slider">
              <div class="footer__partners-item">
                <a href="">
                  <img src="./assets/images/footer-partner1.png" alt="" />
                </a>
              </div>

              <div class="footer__partners-item">
                <a href="">
                  <img src="./assets/images/footer-partner2.png" alt="" />
                </a>
              </div>

              <div class="footer__partners-item">
                <a href="">
                  <img src="./assets/images/footer-partner3.png" alt="" />
                </a>
              </div>

              <div class="footer__partners-item">
                <a href="">
                  <img src="./assets/images/footer-partner4.png" alt="" />
                </a>
              </div>

              <div class="footer__partners-item">
                <a href="">
                  <img src="./assets/images/footer-partner5.png" alt="" />
                </a>
              </div>

              <div class="footer__partners-item">
                <a href="">
                  <img src="./assets/images/footer-partner6.png" alt="" />
                </a>
              </div>

              <div class="footer__partners-item">
                <a href="">
                  <img src="./assets/images/footer-partner7.png" alt="" />
                </a>
              </div>

              <div class="footer__partners-item">
                <a href="">
                  <img src="./assets/images/footer-partner1.png" alt="" />
                </a>
              </div>

              <div class="footer__partners-item">
                <a href="">
                  <img src="./assets/images/footer-partner2.png" alt="" />
                </a>
              </div>

              <div class="footer__partners-item">
                <a href="">
                  <img src="./assets/images/footer-partner3.png" alt="" />
                </a>
              </div>

              <div class="footer__partners-item">
                <a href="">
                  <img src="./assets/images/footer-partner4.png" alt="" />
                </a>
              </div>

              <div class="footer__partners-item">
                <a href="">
                  <img src="./assets/images/footer-partner5.png" alt="" />
                </a>
              </div>

              <div class="footer__partners-item">
                <a href="">
                  <img src="./assets/images/footer-partner6.png" alt="" />
                </a>
              </div>

              <div class="footer__partners-item">
                <a href="">
                  <img src="./assets/images/footer-partner7.png" alt="" />
                </a>
              </div>
            </div>
            <div class="controller">
              <button class="prev"></button>
              <button class="stop"></button>
              <button class="play" style="display: none"></button>
              <button class="next"></button>
            </div>
          </div>
        </div>
        <div class="footer__middle">
          <div class="wrap">
            <div class="flex">
              <div class="col">
                <a href="">
                  <span>기증 희망등록 </span>
                </a>
              </div>
              <div class="col">
                <a href="">
                  <span>아름다운 동행(E-뉴스레터) 신청하기</span>
                </a>
              </div>
            </div>
            <div class="family">
              <label for="f1">
                <span> 유관기관 </span>
              </label>
            </div>
          </div>
        </div>
        <div class="footer__bottom">
          <div class="wrap">
            <div class="logo">
              <a href=""
                ><img src="./assets/images/footer-logo.png" alt=""
              /></a>
            </div>
            <div class="flex flex-1">
              <div class="footer-info">
                <div class="links">
                  <a href="">개인정보 처리방침</a>
                  <a href="">위치안내</a>
                  <a href="">연락체계</a>
                  <a href="">경영공시</a>
                </div>
                <p>
                  서울시 서대문구 충정로 36 국민연금공단충정로사옥5층
                  한국장기조직기증원 (우)03741
                </p>
                <div class="addr">
                  <span> <strong>전화</strong> 02-3447-5632 </span>
                  <span> <strong>팩스</strong> 02-3447-5631 </span>
                  <span> <strong>이메일</strong> koda@koda1458.kr </span>
                </div>
              </div>
              <div class="marks">
                <span>
                  <img src="./assets/images/footer-bottom1.png" alt="" />
                </span>
                <span>
                  <img src="./assets/images/footer-bottom2.png" alt="" />
                </span>
                <span>
                  <img src="./assets/images/footer-bottom3.png" alt="" />
                </span>
              </div>
            </div>
          </div>
        </div>
      </footer>