<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <meta
      name="viewport"
      content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0"
    />
    <title>Document</title>
    <link
      href="https://fonts.googleapis.com/css2?family=Noto+Sans+KR:wght@100;400;500;700&display=swap"
      rel="stylesheet"
    />
    <link rel="stylesheet" href="./assets/plugins/slick/slick.css" />
    <link
      rel="stylesheet"
      href="./assets/plugins/jquery-ui-1.12.1/jquery-ui.css"
    />
    <link rel="stylesheet" href="./assets/css/main.css" />
  </head>
  <body>
    <div class="wrapper">
      <?php
      include_once './include/header.php';
?>

      <div class="container">
        <div class="sub memorial">
          <div class="sub__visual">
            <div class="sub__pagename">
              <div class="wrap">
                <h2>기증자 예우</h2>
                <p>
                  누군가에게 새로운 생명을 선물한 당신, 잊지않고 기억하겠습니다.
                </p>
                <img class="img" src="./assets/images/sub-visual2.png" alt="" />
              </div>
            </div>
            <div class="sub__navigation">
              <div class="wrap flex">
                <a href="/" class="home">홈</a>
                <div class="select">
                  <button>장기·조직 기증</button>
                  <div class="dropdown">
                    <a href="">서브1</a>
                    <a href="">서브2</a>
                    <a href="">서브3</a>
                  </div>
                </div>

                <div class="select">
                  <button>장기·조직 기증</button>
                  <div class="dropdown">
                    <a href="">서브1</a>
                    <a href="">서브2</a>
                    <a href="">서브3</a>
                  </div>
                </div>

                <a href="" class="link">기증희망등록 신청</a>
              </div>
            </div>
          </div>
          <div class="sub__content">
            <div class="sub__lnb">
              <div class="row">
                <a href="" class="link active">기증희망등록</a>
                <div class="depth">
                  <a href="" class="depth-link active">기증희망등록이란?</a>
                  <a href="" class="depth-link">기증희망등록 신청</a>
                </div>
              </div>
              <div class="row">
                <a href="" class="link">기증희망등록</a>
                <div class="depth">
                  <a href="" class="depth-link">기증희망등록이란?</a>
                  <a href="" class="depth-link">기증희망등록 신청</a>
                </div>
              </div>
              <div class="row">
                <a href="" class="link">기증희망등록</a>
                <div class="depth">
                  <a href="" class="depth-link">기증희망등록이란?</a>
                  <a href="" class="depth-link">기증희망등록 신청</a>
                </div>
              </div>
            </div>

            <div class="wrap">
              <div class="sub__header">
                <h2>하늘나라 편지</h2>
              </div>
              <div class="sub__tabs memorial">
                <a href="" class="">기증자 추모관</a>
                <a href="" class="active">하늘나라 편지</a>
                <a href="" class="">수혜자 편지</a>
                <a href="" class="">기증 후 스토리</a>

                <div class="select">
                  <button>기증자 추모관</button>
                  <div class="dropdown">
                    <a href="" class="">기증자 추모관</a>
                    <a href="" class="">하늘나라 편지</a>
                    <a href="" class="">수혜자 편지</a>
                    <a href="" class="">기증 후 스토리</a>
                  </div>
                </div>
              </div>

              <div class="memorial__detail">
                <header>
                  <h2 class="title">자식은 엄마의 닻</h2>
                  <div class="info">
                    <div class="col">기증자 <span>최광현</span></div>
                    <div class="col">추모자 <span>최인식</span></div>
                    <div class="col">등록일 <span>2020-10-19</span></div>
                    <div class="col">조회 <span>4</span></div>
                  </div>
                </header>
                <div class="memorial__detail-body">
                  <img src="./assets/images/memorial-detail-top.png" alt="" />
                  <div class="detail">
                    <p style="white-space: pre-line; line-height: 2em">
                      아들,..잘 지내고 있는거지? 제법 새벽으론 날씨가 쌀쌀한데
                      춥지는 않는지...더운거 싫어 했던 너인지라 아직은 괜찮을것
                      같긴한데 그래도 허허벌판에 있는 너이기에 그래도 마음이
                      쓰이 는구나. 우린 집에서 따뜻하게 지내고 있는것 조차도
                      미안하고. 마음이야 늘 찬바람부니 가슴은 시려오고 엄마는
                      금요일이면 너가 많이 보고싶어 마음 추스리기 힝들어 한단다.
                      특히 내가 야간이라 집에 없을때면 더욱 힘들어하고.
                      금요일이면 자주 너가 집에 와서 통닭에 소주한잔 하고
                      했었으니 그럴수밖에,. 자식은 엄마의 삶을 지탱해 주는
                      닻과같은 존재라고 하는데 지탱해줄 그 닻이 없으니 일렁이는
                      파도에 흔들려 멀미하고 힘들어 할수밖에. 난 그래도 그동안
                      꿈에서라도 세번 널 봤는데 엄마는 한번보고 아직도 널 보지
                      못했나 보더구나. 꿈에도 안보인다고 보고싶다고...엄마 소리
                      듣고싶다고... 여기 저기 다니느라 너도 바쁘겠지만 엄마한테
                      시간내서 한번 들르거라. 널 많이 보고 싶어 아파하고 있으니
                      엄마 마음 쓰다듬어 줄겸. 우리가 덜 아파하고 힘들어 하지
                      않아야 너도 마음 덜 아플것 같은데 우린 아직 그게
                      안되는구나. 사람은 망각 이라는게 있으니 세월이 가다보면
                      받아 들이는 날이 있겠지? 그때 까지는 다가오는대로 마음이
                      가는데로 아파하기도하고 울기도 하고 잠시 잊기도 하면서
                      지내련다. 억지로 마음 저편에 두려 한다고 되는게 아니니까.
                      이퀄라이져2 라는 영화에 그런 대사가 있더구나. 죽은 사람을
                      그리워 하지 않으면 두번 죽이는 거라고... 할머니가 죽은
                      형에 대하여 동생에게 그렇게 이야기 하셨다네. 그래서 그
                      동생은 그림을 잘 그리는데 다그리고나면 맨끝에 낙관찍듯이
                      형의 모습을 그려넣더구나.. 가족이니까 잊지 말라는거겠지?
                      잊는다고 잊혀 지겠냐마는 그리워하는것도 사랑이 아니겠나
                      싶다. 어제는 다희 누나 친구 은빈이 아빠가 너가 간길을
                      가셨단다. 엄마도 먼져 가셨었는데 ...주무시다 심정지가
                      오셨나본데..아이들이 참 놀랬을것 같더구나. 허망하기도
                      했을것 같고...건강하셨다 하는데 그렇게 갑자기 돌아 가셔서
                      마음 참 많이 아플것같고...갑자기 널 보낸 우리와 같을것
                      같다는 생각에 마음 아프기도 하고... 아들... 세상 밖
                      문을일찍 열고 나가 우리와 헤어졌지만 우린 늘 함께 하니까
                      너무 외로워 하지는 말거라. 우리도 너가 간길 언젠가는 가야
                      하는게 현실이니까 잠시 떨 어져 있는거라고 생각하면 마음 덜
                      아프지 않을까? 원래 이별이란 마음 아픈일 이니까 아프면
                      아픈대로 견뎌 나가자 늘 그러했듯이 넌 너가 있는데서 평안
                      하기만 하면돼. 시간되면 엄마나 누나 에게 가끔 꿈에라도
                      보여주고...편안한 모습으로.. 우린 매일 그렇게 되기를
                      기도하고. 미사 봉헌도하고 매주 너를 찿아가니까 .그렇게나마
                      만나며 지내자꾸나. 다행히 오늘은 덜 마음 아파하며 글을
                      쓴것같구나 .잘 지내고,... 또 올께. 아빠가.
                    </p>
                  </div>
                  <img
                    src="./assets/images/memorial-detail-bottom.png"
                    alt=""
                  />
                </div>

                <div class="memorial__detail-foot">
                  <a href="" class="active">수정</a>
                  <a href="" class="">삭제</a>
                  <a href="" class="">목록</a>
                </div>
              </div>

              <div class="memorial__comment">
                <div class="memorial__comment-author">
                  <div class="col">
                    <strong>이름</strong>
                    <div class="input"><input type="text" /></div>
                  </div>
                  <div class="col">
                    <strong>비밀번호</strong>
                    <div class="input"><input type="password" /></div>
                  </div>
                </div>
                <div class="memorial__comment-form">
                  <div class="textarea">
                    <textarea
                      name=""
                      id=""
                      placeholder="기증자에 대한 추모 분위기를 해치거나, 비방의 글 등이 게시가 될 경우 관리자에 의해 삭제 될 수 있습니다. "
                    ></textarea>
                  </div>
                  <button>댓글등록</button>
                </div>

                <div class="memorial__detail-comment">
                  <div class="memorial__comment-total">댓글 <span>1</span></div>
                  <div class="list">
                    <div class="memorial__comment-title">
                      <div class="info">
                        <strong>행복하자</strong>
                        <span class="date">2020-10-12</span>
                        <a href="">삭제</a>
                      </div>
                      <p>
                        세상에서 가장 아름다운 아기, 진정한 사랑을 실천하고 간
                        정민아♥ 영원히 너를 기억할께!<br />
                        더이상 아픔과 슬픔과 눈물이 없는 그곳에서 평안하길
                        바라며 훗날 다시 만나자
                      </p>
                    </div>

                    <div class="memorial__comment-title">
                      <div class="info">
                        <strong>행복하자</strong>
                        <span class="date">2020-10-12</span>
                        <a href="">삭제</a>
                      </div>
                      <p>
                        세상에서 가장 아름다운 아기, 진정한 사랑을 실천하고 간
                        정민아♥ 영원히 너를 기억할께!<br />
                        더이상 아픔과 슬픔과 눈물이 없는 그곳에서 평안하길
                        바라며 훗날 다시 만나자
                      </p>
                    </div>

                    <div class="memorial__comment-title">
                      <div class="info">
                        <strong>행복하자</strong>
                        <span class="date">2020-10-12</span>
                        <a href="">삭제</a>
                      </div>
                      <p>
                        세상에서 가장 아름다운 아기, 진정한 사랑을 실천하고 간
                        정민아♥ 영원히 너를 기억할께!<br />
                        더이상 아픔과 슬픔과 눈물이 없는 그곳에서 평안하길
                        바라며 훗날 다시 만나자
                      </p>
                    </div>

                    <div class="memorial__comment-title">
                      <div class="info">
                        <strong>행복하자</strong>
                        <span class="date">2020-10-12</span>
                        <a href="">삭제</a>
                      </div>
                      <p>
                        세상에서 가장 아름다운 아기, 진정한 사랑을 실천하고 간
                        정민아♥ 영원히 너를 기억할께!<br />
                        더이상 아픔과 슬픔과 눈물이 없는 그곳에서 평안하길
                        바라며 훗날 다시 만나자
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <?php
      include_once './include/footer.php';
?>
    </div>
    <div id="loader">
      <span class="loader-overlay">
        <span class="loader-inner"></span>
      </span>
    </div>

    <script src="./assets/plugins/jquery/jquery.js"></script>
    <script src="./assets/plugins/jquery-ui-1.12.1/jquery-ui.js"></script>
    <script src="./assets/plugins/slick/slick.js"></script>
    <script src="./assets/js/ui.js"></script>
  </body>
</html>
